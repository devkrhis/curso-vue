new Vue({
    el: '#desafio',
    data: {
        SEU_NOME: 'Krhistopher',
        IDADE: '24',
        idadepor3: 24 * 3
    }
})